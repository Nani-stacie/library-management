<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login_form.php");
    exit;
}

if (!isset($_GET['id'])) {
    die("Book ID missing.");
}
$conn = new mysqli("localhost", "root", "", "user_auth", 3307);
$stmt = $conn->prepare("SELECT title, author, year FROM books WHERE id = ?");
$stmt->bind_param("i", $_GET['id']);
$stmt->execute();
$stmt->bind_result($title, $author, $year);
$stmt->fetch();
$stmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Book</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Orbitron&display=swap" rel="stylesheet">
    <link href="style_head.css" rel="stylesheet">
</head>
<body>
<div class="container py-5">
    <form method="post" action="update_books.php" onsubmit="return validateBookForm();" class="w-50 mx-auto sci-card">
        <h2 class="sci-title">Edit Book</h2>
        <input type="hidden" name="id" value="<?php echo $_GET['id']; ?>">
        <div class="mb-3">
            <label>Title</label>
            <input type="text" name="title" value="<?php echo htmlspecialchars($title); ?>" class="form-control" required>
        </div>
        <div class="mb-3">
            <label>Author</label>
            <input type="text" name="author" value="<?php echo htmlspecialchars($author); ?>" class="form-control" required>
        </div>
        <div class="mb-3">
            <label>Year</label>
            <input type="number" name="year" value="<?php echo $year; ?>" class="form-control" required>
        </div>
        <button type="submit" class="btn btn-sci w-100">Update Book</button>
    </form>
</div>

<script>
function validateBookForm() {
    const year = parseInt(document.querySelector('input[name="year"]').value);
    const current = new Date().getFullYear();
    return year >= 1500 && year <= current;
}
</script>
</body>
</html>
