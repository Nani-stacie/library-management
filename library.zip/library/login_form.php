<?php
session_start();

$msg = "";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $conn = new mysqli("localhost", "root", "", "user_auth", 3307);
    if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

    $username = trim($_POST['username']);
    $password = $_POST['password'];

    $stmt = $conn->prepare("SELECT id, password, role FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $stmt->bind_result($id, $hash, $role);
        $stmt->fetch();

        if ($password === $hash) {
            $_SESSION['user_id'] = $id;
            $_SESSION['username'] = $username;
            $_SESSION['role'] = $role;

            if ($role === 'admin') {
                header("Location: dashboard.php");
            } elseif ($role === 'outsider') {
                header("Location: outsider_dashboard.php");
            } else {
                $msg = "❌ Unknown role. Contact admin.";
            }
            exit;
        } else {
            $msg = "❌ Incorrect password.";
        }
    } else {
        $msg = "⚠️ Username not found.";
    }

    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Orbitron&display=swap" rel="stylesheet">
    <link href="style_head.css" rel="stylesheet">
</head>
<body>
<div class="container py-5">
    <form method="post" class="w-50 mx-auto sci-card">
        <h2 class="sci-title">Login</h2>

        <?php if (!empty($msg)): ?>
            <div class="alert alert-danger"><?= $msg ?></div>
            <div class="text-center mt-3 d-grid gap-2">
                <a href="login_form.php" class="btn btn-sci">Try Again</a>
                <a href="outsider_register.php" class="btn btn-outline-light">Register</a>
            </div>
        <?php endif; ?>

        <?php if (empty($msg)): ?>
            <div class="mb-3">
                <label>Username</label>
                <input type="text" name="username" class="form-control" required>
            </div>
            <div class="mb-3">
                <label>Password</label>
                <input type="password" name="password" class="form-control" required>
            </div>
            <input type="submit" value="Login" class="btn btn-sci w-100">
            <div class="text-center mt-3">
                <a href="outsider_register.php" class="btn btn-outline-light">Register</a>
            </div>
        <?php endif; ?>
    </form>
</div>
</body>
</html>
