<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'outsider') {
    header("Location: login_form.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$book_id = $_GET['book_id'];

$conn = new mysqli("localhost", "root", "", "user_auth", 3307);

$check = $conn->prepare("SELECT status FROM books WHERE id = ?");
$check->bind_param("i", $book_id);
$check->execute();
$check->bind_result($status);
$check->fetch();
$check->close();

if ($status === 'available') {
    $stmt = $conn->prepare("INSERT INTO cart (user_id, book_id) VALUES (?, ?)");
    $stmt->bind_param("ii", $user_id, $book_id);
    $stmt->execute();
    $stmt->close();

    $update = $conn->prepare("UPDATE books SET status = 'borrowed' WHERE id = ?");
    $update->bind_param("i", $book_id);
    $update->execute();
    $update->close();
}

$conn->close();
header("Location: view_cart.php");
exit;
