<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login_form.php");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Orbitron&display=swap" rel="stylesheet">
    <link href="style_head.css" rel="stylesheet">
</head>
<body>
<div class="container py-5 text-center">
    <h1 class="sci-title">Welcome, <?php echo htmlspecialchars($_SESSION['username']); ?>!</h1>
    <div class="d-grid gap-3 col-md-6 mx-auto mt-4">
        <a href="view_book.php" class="btn btn-sci">View Books</a>
        <a href="admin_borrowed_books.php" class="btn btn-sci">Borrowed Books</a>
        <a href="add_books.php" class="btn btn-sci">Add Book</a>
        <a href="logout.php" class="btn btn-danger">Logout</a>
    </div>
</div>
</body>
</html>
