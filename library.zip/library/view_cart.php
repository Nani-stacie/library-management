<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'outsider') {
    header("Location: login_form.php");
    exit;
}
$conn = new mysqli("localhost", "root", "", "user_auth", 3307);
$stmt = $conn->prepare("SELECT cart.id, books.title, books.author FROM cart
                       JOIN books ON cart.book_id = books.id
                       WHERE cart.user_id = ?");
$stmt->bind_param("i", $_SESSION['user_id']);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html>
<head>
    <title>My Cart</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Orbitron&display=swap" rel="stylesheet">
    <link href="style_head.css" rel="stylesheet">
</head>
<body>
<div class="container py-5">
    <h2 class="sci-title">My Borrowed Books</h2>
    <div class="sci-card">
        <table class="table table-dark table-bordered">
            <thead class="table-primary text-dark">
                <tr><th>Title</th><th>Author</th><th>Action</th></tr>
            </thead>
            <tbody>
                <?php while($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?= htmlspecialchars($row['title']) ?></td>
                        <td><?= htmlspecialchars($row['author']) ?></td>
                        <td><a href="delete_from_cart.php?id=<?= $row['id'] ?>" class="btn btn-danger btn-sm">Remove</a></td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
        <a href="outsider_dashboard.php" class="btn btn-outline-light mt-3">⬅ Back to Dashboard</a>
        <a href="view_books.php" class="btn btn-sci mt-3">Browse Books</a>
    </div>
</div>
</body>
</html>
