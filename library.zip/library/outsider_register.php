<?php
session_start();
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST['username']);
    $password = ($_POST['password']);

    $conn = new mysqli("localhost", "root", "", "user_auth", 3307);
    if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

    $check = $conn->prepare("SELECT id FROM users WHERE username = ?");
    $check->bind_param("s", $username);
    $check->execute();
    $check->store_result();

    if ($check->num_rows > 0) {
        $msg = "Username already exists.";
    } else {
        $stmt = $conn->prepare("INSERT INTO users (username, password, role) VALUES (?, ?, 'outsider')");
        $stmt->bind_param("ss", $username, $password);
        $stmt->execute();
        $msg = "Registered successfully.";
        $stmt->close();
    }

    $check->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Register</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Orbitron&display=swap" rel="stylesheet">
    <link href="style_head.css" rel="stylesheet">
</head>
<body>
<div class="container py-5">
    <form method="post" class="w-50 mx-auto sci-card">
        <h2 class="sci-title">Register</h2>
        <?php if (!empty($msg)) echo "<div class='alert alert-info'>$msg</div>"; ?>
        <label>Username</label>
        <input type="text" name="username" class="form-control mb-3" required>
        <label>Password</label>
        <input type="password" name="password" class="form-control mb-3" required>
        <button type="submit" class="btn btn-sci w-100">Register</button>
        <div class="text-center mt-3">
            <a href="login_form.php" class="btn btn-outline-light">Already registered? Login</a>
        </div>
    </form>
</div>
</body>
</html>
