<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login_form.php");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Add Book</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Orbitron&display=swap" rel="stylesheet">
    <link href="style_head.css" rel="stylesheet">
</head>
<body>
<div class="container py-5">
    <form method="post" action="insert_books.php" onsubmit="return validateBookForm();" class="w-50 mx-auto sci-card">
        <h2 class="sci-title">Add Book</h2>
        <div class="mb-3">
            <label>Title</label>
            <input type="text" id="title" name="title" class="form-control" required>
        </div>
        <div class="mb-3">
            <label>Author</label>
            <input type="text" id="author" name="author" class="form-control" required>
        </div>
        <div class="mb-3">
            <label>Year</label>
            <input type="number" id="year" name="year" class="form-control" required>
        </div>
        <button type="submit" class="btn btn-sci w-100">Add Book</button>
    </form>
</div>

<script>
function validateBookForm() {
    const y = parseInt(document.getElementById("year").value);
    const current = new Date().getFullYear();
    if (y < 1500 || y > current) {
        alert("Enter a valid year between 1500 and " + current);
        return false;
    }
    return true;
}
</script>
</body>
</html>
