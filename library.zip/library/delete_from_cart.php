<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'outsider') {
    header("Location: login_form.php");
    exit;
}

$cart_id = $_GET['id'];
$conn = new mysqli("localhost", "root", "", "user_auth", 3307);

$get = $conn->prepare("SELECT book_id FROM cart WHERE id = ?");
$get->bind_param("i", $cart_id);
$get->execute();
$get->bind_result($book_id);
$get->fetch();
$get->close();

$delete = $conn->prepare("DELETE FROM cart WHERE id = ? AND user_id = ?");
$delete->bind_param("ii", $cart_id, $_SESSION['user_id']);
$delete->execute();
$delete->close();

$restore = $conn->prepare("UPDATE books SET status = 'available' WHERE id = ?");
$restore->bind_param("i", $book_id);
$restore->execute();
$restore->close();

$conn->close();
header("Location: view_cart.php");
exit;
