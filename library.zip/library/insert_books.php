<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login_form.php");
    exit;
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $title  = trim($_POST['title']);
    $author = trim($_POST['author']);
    $year   = $_POST['year'];

    $conn = new mysqli("localhost", "root", "", "user_auth", 3307);
    if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

    $stmt = $conn->prepare("INSERT INTO books (title, author, year) VALUES (?, ?, ?)");
    $stmt->bind_param("ssi", $title, $author, $year);

    $message = "";
    $messageClass = "";

    if ($stmt->execute()) {
        $message = "✅ Book added successfully!";
        $messageClass = "success";
    } else {
        $message = "❌ Failed to add book: " . $stmt->error;
        $messageClass = "danger";
    }

    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Insert Book</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Orbitron&display=swap" rel="stylesheet">
    <link href="style_head.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container mt-5">

    <?php if (!empty($message)): ?>
        <div class="alert alert-<?php echo $messageClass; ?> text-center">
            <?php echo $message; ?>
        </div>
    <?php endif; ?>

    <div class="text-center">
        <a href="add_books.php" class="btn btn-outline-primary">Add Another Book</a>
        <a href="view_book.php" class="btn btn-success">View Books</a>
        <a href="dashboard.php" class="btn btn-secondary">Dashboard</a>
    </div>

</div>
</body>
</html>
