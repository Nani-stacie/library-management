<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login_form.php");
    exit;
}

if (!isset($_GET['id'])) {
    echo "Book ID not specified.";
    exit;
}

$bookId = $_GET['id'];

$conn = new mysqli("localhost", "root", "", "user_auth", 3307);
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

$stmt = $conn->prepare("DELETE FROM books WHERE id = ?");
$stmt->bind_param("i", $bookId);

if ($stmt->execute()) {
    header("Location: view_book.php?deleted=1");
    exit;
} else {
    echo "❌ Failed to delete book: " . $stmt->error;
}

$stmt->close();
$conn->close();
?>
