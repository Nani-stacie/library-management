<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login_form.php");
    exit;
}

$conn = new mysqli("localhost", "root", "", "user_auth", 3307);
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

$search = "";
if (isset($_GET['search'])) {
    $search = $_GET['search'];
    $stmt = $conn->prepare("SELECT id, title, author, year FROM books WHERE title LIKE ? OR author LIKE ?");
    $like = "%$search%";
    $stmt->bind_param("ss", $like, $like);
    $stmt->execute();
    $result = $stmt->get_result();
} else {
    $result = $conn->query("SELECT id, title, author, year FROM books");
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Sci-Fi Books</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Orbitron&display=swap" rel="stylesheet">
    <link href="style_head.css" rel="stylesheet">
</head>
<body>
<div class="container py-5">
    <h1 class="sci-title">Books Collection</h1>

    <form method="get" action="view_book.php" class="row g-3 mb-4 justify-content-center">
        <div class="col-md-4">
            <input type="text" name="search" placeholder="Search by title or author" class="form-control" value="<?php echo htmlspecialchars($search); ?>">
        </div>
        <div class="col-auto">
            <button type="submit" class="btn btn-sci">Search</button>
            <a href="view_book.php" class="btn btn-outline-light">Reset</a>
        </div>
    </form>

    <div class="sci-card">
        <table class="table table-dark table-hover">
            <thead class="table-primary text-dark">
                <tr>
                    <th>ID</th>
                    <th>Title</th>
                    <th>Author</th>
                    <th>Year</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
            <?php
            if ($result && $result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . htmlspecialchars($row['id']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['title']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['author']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['year']) . "</td>";
                    echo "<td>";
                    echo "<a href='edit_books.php?id=" . $row['id'] . "' class='btn btn-warning btn-sm me-1'>Edit</a>";
                    echo "<a href='delete_books.php?id=" . $row['id'] . "' class='btn btn-danger btn-sm' onclick='return confirm(\"Are you sure?\");'>Delete</a>";
                    echo "</td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='5' class='text-center'>No Sci-Fi books found.</td></tr>";
            }
            $conn->close();
            ?>
            </tbody>
        </table>
    </div>

    <div class="mt-4 text-center">
        <a href="add_books.php" class="btn btn-sci me-2">Add Book</a>
        <a href="dashboard.php" class="btn btn-outline-light">Back to Dashboard</a>
    </div>
</div>
</body>
</html>
