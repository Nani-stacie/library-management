<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'outsider') {
    header("Location: login_form.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$conn = new mysqli("localhost", "root", "", "user_auth", 3307);

$search = "";
if (isset($_GET['search'])) {
    $search = $_GET['search'];
    $like = "%$search%";
    $books_query = $conn->prepare("SELECT * FROM books WHERE (title LIKE ? OR author LIKE ?)");
    $books_query->bind_param("ss", $like, $like);
    $books_query->execute();
    $books = $books_query->get_result();
} else {
    $books = $conn->query("SELECT * FROM books");
}

$cart = [];
$cart_map = [];
$cart_query = $conn->prepare("SELECT book_id, id FROM cart WHERE user_id = ?");
$cart_query->bind_param("i", $user_id);
$cart_query->execute();
$cart_result = $cart_query->get_result();
while ($row = $cart_result->fetch_assoc()) {
    $cart[] = $row['book_id'];
    $cart_map[$row['book_id']] = $row['id'];
}
$cart_query->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Browse Books</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Orbitron&display=swap" rel="stylesheet">
    <link href="style_head.css" rel="stylesheet">
</head>
<body>
<div class="container py-5">
    <h2 class="sci-title">Available Books</h2>

    <form method="get" action="view_books.php" class="row g-3 mb-4 justify-content-center">
        <div class="col-md-4">
            <input type="text" name="search" placeholder="Search by title or author" class="form-control" value="<?php echo htmlspecialchars($search); ?>">
        </div>
        <div class="col-auto">
            <button type="submit" class="btn btn-sci">Search</button>
            <a href="view_books.php" class="btn btn-outline-light">Reset</a>
        </div>
    </form>

    <div class="sci-card">
        <table class="table table-dark table-striped text-center align-middle">
            <thead class="table-primary text-dark">
                <tr><th>Title</th><th>Author</th><th>Year</th><th>Status</th><th>Action</th></tr>
            </thead>
            <tbody>
            <?php if ($books->num_rows > 0): ?>
                <?php while ($book = $books->fetch_assoc()): ?>
                    <tr>
                        <td><?= htmlspecialchars($book['title']) ?></td>
                        <td><?= htmlspecialchars($book['author']) ?></td>
                        <td><?= htmlspecialchars($book['year']) ?></td>
                        <td>
                            <?= $book['status'] === 'borrowed' ? 'Borrowed' : 'Available' ?>
                        </td>
                        <td>
                            <?php if ($book['status'] === 'borrowed'): ?>
                                <button class="btn btn-secondary btn-sm" disabled>Borrowed</button>
                            <?php elseif (in_array($book['id'], $cart)): ?>
                                <a href="delete_from_cart.php?id=<?= $cart_map[$book['id']] ?>" class="btn btn-danger btn-sm">Remove</a>
                            <?php else: ?>
                                <a href="add_to_cart.php?book_id=<?= $book['id'] ?>" class="btn btn-sci btn-sm">Add to Cart</a>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr><td colspan="5" class="text-center">No books found.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
        <div class="text-center mt-3">
            <a href="outsider_dashboard.php" class="btn btn-outline-light">Back to Dashboard</a>
            <a href="view_cart.php" class="btn btn-sci">View My Cart</a>
        </div>
    </div>
</div>
</body>
</html>