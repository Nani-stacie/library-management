<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: login_form.php");
    exit;
}

$conn = new mysqli("localhost", "root", "", "user_auth", 3307);
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

$query = "
    SELECT b.title, b.author, b.year, u.username
    FROM cart c
    JOIN books b ON c.book_id = b.id
    JOIN users u ON c.user_id = u.id
    WHERE b.status = 'borrowed'
";
$result = $conn->query($query);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Borrowed Books</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Orbitron&display=swap" rel="stylesheet">
    <link href="style_head.css" rel="stylesheet">
</head>
<body>
<div class="container py-5">
    <h2 class="sci-title">Borrowed Books</h2>

    <div class="sci-card">
        <table class="table table-dark table-striped text-center align-middle">
            <thead class="table-primary text-dark">
                <tr><th>Title</th><th>Author</th><th>Year</th><th>Borrowed By</th></tr>
            </thead>
            <tbody>
            <?php if ($result->num_rows > 0): ?>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?= htmlspecialchars($row['title']) ?></td>
                        <td><?= htmlspecialchars($row['author']) ?></td>
                        <td><?= htmlspecialchars($row['year']) ?></td>
                        <td><?= htmlspecialchars($row['username']) ?></td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr><td colspan="4">No books are currently borrowed.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
        <div class="text-center mt-3">
            <a href="dashboard.php" class="btn btn-outline-light">⬅ Back to Admin Dashboard</a>
        </div>
    </div>
</div>
</body>
</html>
