<?php
session_start();

$registerMsg = "";
$msgClass = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST['username']);
    $password = ($_POST['password']);

    $conn = new mysqli("localhost", "root", "", "user_auth", 3307);
    if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

    $check = $conn->prepare("SELECT id FROM users WHERE username = ?");
    $check->bind_param("s", $username);
    $check->execute();
    $check->store_result();

    if ($check->num_rows > 0) {
        $registerMsg = "⚠️ Username already registered. Please login instead.";
        $msgClass = "warning";
    } else {
        $stmt = $conn->prepare("INSERT INTO users (username, password) VALUES (?, ?)");
        $stmt->bind_param("ss", $username, $password);
        if ($stmt->execute()) {
            $registerMsg = "✅ Registered successfully!";
            $msgClass = "success";
        } else {
            $registerMsg = "❌ Registration failed: " . $stmt->error;
            $msgClass = "danger";
        }
        $stmt->close();
    }

    $check->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Register</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Orbitron&display=swap" rel="stylesheet">
    <link href="style_head.css" rel="stylesheet">
</head>
<body>
<div class="container py-5">
    <form method="post" onsubmit="return validateRegisterForm();" class="w-50 mx-auto sci-card">
        <h2 class="sci-title">Register</h2>

        <?php if (!empty($registerMsg)): ?>
            <div class="alert alert-<?php echo $msgClass; ?>"><?php echo $registerMsg; ?></div>
        <?php endif; ?>

        <div class="mb-3">
            <label>Username</label>
            <input type="text" id="username" name="username" class="form-control" required>
        </div>
        <div class="mb-3">
            <label>Password</label>
            <input type="password" id="password" name="password" class="form-control" required>
        </div>
        <button type="submit" class="btn btn-sci w-100">Register</button>

        <div class="text-center mt-3">
            <a href="login_form.php" class="btn btn-outline-light">Already registered? Login</a>
        </div>
    </form>
</div>

<script>
function validateRegisterForm() {
    const u = document.getElementById("username").value.trim();
    const p = document.getElementById("password").value.trim();
    if (u === "" || p === "") {
        alert("All fields required.");
        return false;
    }
    if (p.length < 6) {
        alert("Password must be at least 6 characters.");
        return false;
    }
    return true;
}
</script>
</body>
</html>
